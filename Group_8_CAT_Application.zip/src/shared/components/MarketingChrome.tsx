import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Mail, Menu, MessageCircle, X, LogIn, UserCircle2 } from "lucide-react";
import { Logo } from "@/shared/components/Logo";
import { useAuth } from "@/shared/context/AuthContext";

import {
  WHATSAPP_URL,
  waLink,
  WHATSAPP_NUMBER,
  formatWhatsAppNumber,
  SUPPORT_ACTION,
  SUPPORT_EMAIL,
  WHATSAPP_CONFIGURED,
} from "@/shared/contact";
import { SupportLink } from "@/shared/components/SupportLink";
export { WHATSAPP_URL, waLink, WHATSAPP_NUMBER, formatWhatsAppNumber };

const NAV_LINKS = [
  { label: "Journey", to: "/" },
  { label: "Listings", to: "/listings" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
  { label: "List property", to: "/list-property" },
  { label: "Landlord Portal", to: "/landlord" },
] as const;

function Wordmark() {
  return <Logo showTagline />;
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <header className="fixed inset-x-0 top-0 z-50 border-b border-transparent bg-background/65 backdrop-blur-xl supports-[backdrop-filter]:bg-background/55">
        <nav
          className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 md:px-8"
          aria-label="Main navigation"
        >
          <Wordmark />

          <div className="hidden items-center gap-8 md:flex">
            {NAV_LINKS.map((link) => (
              <Link key={link.label} to={link.to} className="nav-link">
                {link.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <Link
                to="/admin"
                className="inline-flex items-center gap-2 min-h-10 rounded-full bg-primary/10 px-4 text-sm font-medium text-primary hover:bg-primary/20 transition-colors"
              >
                <LogIn className="size-4" aria-hidden="true" />
                <span>Admin</span>
              </Link>
            ) : null}
            <Link
              to="/listings"
              className="hidden min-h-10 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-glow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background sm:inline-flex"
            >
              Browse Listings
            </Link>
            <button
              type="button"
              className="inline-flex size-10 items-center justify-center rounded-full border border-border bg-card text-foreground transition-colors hover:bg-accent md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((value: boolean) => !value)}
            >
              {open ? (
                <X className="size-4" aria-hidden="true" />
              ) : (
                <Menu className="size-4" aria-hidden="true" />
              )}
            </button>
          </div>
        </nav>

        {open ? (
          <div className="border-t border-border bg-background/95 backdrop-blur-xl md:hidden">
            <div className="mx-auto flex max-w-7xl flex-col gap-1 px-5 py-6">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.label}
                  to={link.to}
                  className="min-h-12 rounded-2xl px-3 py-3 text-sm font-medium text-foreground hover:bg-accent"
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              {user ? (
                <Link
                  to="/admin"
                  className="mt-3 inline-flex items-center justify-center gap-2 min-h-12 rounded-full bg-primary/10 px-5 text-sm font-semibold text-primary hover:bg-primary/20 transition-colors"
                  onClick={() => setOpen(false)}
                >
                  <LogIn className="size-4" aria-hidden="true" />
                  Admin
                </Link>
              ) : null}
              <Link
                to="/listings"
                className="mt-3 inline-flex min-h-12 items-center justify-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-glow"
                onClick={() => setOpen(false)}
              >
                Browse Listings
              </Link>
            </div>
          </div>
        ) : null}
      </header>
    </>
  );
}

function FooterColumn({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <p className="text-sm font-semibold">{title}</p>
      <ul className="mt-5 space-y-3">
        {links.map(([label, href]) => (
          <li key={label}>
            <a
              href={href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function SiteFooter() {
  return (
    <footer id="contact" className="border-t border-border bg-panel">
      <div className="mx-auto max-w-7xl px-5 py-14 md:px-8">
        <div className="grid gap-12 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div>
            <Wordmark />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Verified student housing near Kenyan campuses. Browse freely, then talk directly to
              the people listing it.
            </p>
            <SupportLink
              message="Hi UniHub, I'd like help finding verified student housing"
              className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-highlight"
              aria-label={`Contact UniHub support: ${SUPPORT_ACTION.label}`}
            >
              {WHATSAPP_CONFIGURED ? (
                <MessageCircle className="size-4" aria-hidden="true" />
              ) : (
                <Mail className="size-4" aria-hidden="true" />
              )}
              {SUPPORT_ACTION.label}
            </SupportLink>
          </div>
          <FooterColumn
            title="Product"
            links={[
              ["Listings", "/listings"],
              ["Hostels", "/listings"],
              ["Map", "/#locations"],
              ["Residences", "/#residences"],
              ["Landlord Portal", "/landlord"],
            ]}
          />
          <FooterColumn
            title="Company"
            links={[
              ["About", "/about"],
              ["Contact", "/contact"],
              ["Become a partner", "/list-property"],
            ]}
          />
          <FooterColumn
            title="Legal"
            links={[
              ["Privacy", "/privacy"],
              ["Terms", "/terms"],
              ["Your consent", "/consent"],
              ["Email us", "/contact"],
            ]}
          />
        </div>
        <div className="mt-14 flex flex-col gap-3 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 UniHub · Student housing in Kenya</p>
          <div className="flex items-center gap-4">
            <Link
              to="/admin"
              className="text-muted-foreground hover:text-foreground transition-colors"
              title="Admin Portal"
              aria-label="Admin Portal"
            >
              <UserCircle2 className="size-4" />
            </Link>
            <a
              href={`mailto:${SUPPORT_EMAIL}`}
              className="flex items-center gap-2 transition-colors hover:text-foreground"
            >
              <Mail className="size-3.5" aria-hidden="true" /> {SUPPORT_EMAIL}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export function MarketingShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="page-frame min-h-screen overflow-x-hidden bg-background text-foreground">
      <SiteHeader />
      <main id="main" className="pt-20">
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}
