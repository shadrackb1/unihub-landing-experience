# UniHub — Pre-Publication Checklist

**Project:** UniHub — Verified Student Housing Discovery Platform  
**Group:** Group 8  
**Course:** KLS 126 — Data Science for Lawyers, Kabarak University  
**Date:** 21st October 2026  
**Version:** 1.0

---

This checklist is generated from the single source of truth at `src/shared/prePublicationChecklist.ts`. Every item must be met before a landlord's listing is published. The checklist is also exposed as an admin page and API endpoint so the document and the app cannot drift apart.

Citations are to the Data Protection Act, 2019 (Act No. 24 of 2019) and the Data Protection (General) Regulations, 2021 (Legal Notice No. 263 of 2021).

---

| # | Requirement | Authority | Control | Evidence | Status |
|---|---|---|---|---|---|
| 1 | Every processing operation has one lawful basis, and a second basis is not leaned on for the same operation. | Act s.30(1); Regulations reg. 5(2) | Each consent purpose states its lawful basis. Legitimate interests are cited as s.30(1)(b)(vii), not as a sub-paragraph that does not exist. | `src/shared/consentPurposes.ts` | met |
| 2 | Personal data is collected for explicit, specified purposes and is not further processed incompatibly with them. | Act s.25(c); s.30(2) | The four consent purposes are fixed in one catalogue, and the catalogue is also what is written to every consent record. | `src/shared/consentPurposes.ts` | met |
| 3 | Only the personal data that is necessary for the stated purpose is collected. | Act s.25(d) | The national ID number is held for verification only, is never published, and is excluded from every export. | `src/shared/dataDictionary.ts; src/server/dataTransfer.ts` | met |
| 4 | Personal data is accurate and kept up to date, and inaccurate data is rectified without delay. | Act s.25(f); s.40 | Landlords confirm the accuracy of their details on the consent screen and can update them; reviewers can suspend an account whose details do not match. | `src/routes/consent.tsx; prisma/schema.prisma` | met |
| 5 | Personal data is kept no longer than is necessary, and is deleted at the end of the retention period. | Act s.25(g); s.39 | Every field in the data dictionary carries a retention period, and the export tooling states the retention for each dataset it writes. | `src/shared/dataDictionary.ts` | met |
| 6 | Personal data is not transferred outside Kenya without proof of adequate safeguards or the data subject's consent. | Act s.25(h); s.48; s.49 | The consent screen states the transfer risks and the safeguards relied on, and names the processors and the locations. | `src/routes/consent.tsx` | met |
| 7 | Before collecting personal data, the person is told the rights, the purposes, the third parties, the security measures and the consequences of not providing the data. | Act s.29(a)–(h) | Each of the eight items in s.29 is answered on the consent screen and in the written consent form. | `src/routes/consent.tsx; docs/CONSENT_FORM.md` | met |
| 8 | Consent is specific to each purpose, freely given, and never bundled across purposes. | Act s.32; Regulations reg. 4(3)–(4) | Every purpose has its own tick box, pre-ticked boxes are not accepted by the server, and a grant writes one record per purpose. | `src/shared/consentPurposes.ts; src/server/consent.ts; tests/consent.test.ts` | met |
| 9 | The controller can show that consent was given, and when. | Act s.32(1); s.32(3) | Each record stores the exact wording shown, the version of that wording, the date and time of the grant, and the date and time of any withdrawal. A withdrawal is recorded rather than deleted. | `src/server/consent.ts; prisma/schema.prisma` | met |
| 10 | Consent can be withdrawn at any time, and withdrawing one part of the processing restricts that part. | Act s.32(2)–(3); Regulations reg. 4(5) | The consent screen has a withdraw control for every purpose and for all purposes at once, and each withdrawal is timestamped. | `src/server/consent.ts; src/routes/consent.tsx` | met |
| 11 | The person can be informed of the use, access their data, object, have false data corrected, and have data erased. | Act s.26(a)–(e); s.36; s.40 | The consent screen and the privacy policy set out each right with its section number, and the access, export and deletion routes are served to the signed-in person. | `src/routes/privacy.tsx; src/routes/api/consent.ts` | met |
| 12 | The person can receive their data in a structured, commonly used, machine-readable format. | Act s.38 | The export route writes CSV for the person's own consent records and for the platform data an administrator is allowed to export. | `src/server/dataTransfer.ts; src/routes/api/data/export.ts` | met |
| 13 | The person can complain to the Data Commissioner. | Act s.56 | The privacy policy and the consent form name the Office of the Data Protection Commissioner and how to reach it. | `src/routes/privacy.tsx; docs/CONSENT_FORM.md` | met |
| 14 | Appropriate technical and organisational measures are designed into the processing. | Act s.41; s.42 | Role checks run on the server for every protected route, the role is read from the database rather than the request, and the database file is not published with the source code. | `src/server/authz.ts; tests/authz.test.ts` | met |
| 15 | A breach of security of personal data is notified to the Data Commissioner and communicated to affected people. | Act s.43; Regulations regs. 37–38 | The breach procedure is written down in the privacy policy: who decides, what is notified and within what period. | `docs/DPIA-UniHub.md; src/routes/privacy.tsx` | partly |
| 16 | No decision is taken about a person by automated means alone. | Act s.35 | The platform does not profile, score or auto-approve a landlord; every approval is a human decision recorded in the review note. | `prisma/schema.prisma; src/features/admin` | met |
| 17 | A child's data is not processed without the parent's or guardian's consent. | Act s.33 | The consent screen asks the person to confirm they are 18 or over, and the platform refuses to accept a consent from anyone under 18. | `src/routes/consent.tsx` | met |
| 18 | The service is not directed at children and no child is knowingly onboarded. | Act s.33(1); Regulations reg. 13 | The platform is a student housing service for university students; the age confirmation is a required tick box, not an optional one. | `src/routes/consent.tsx` | partly |
| 19 | Data collected from a source other than the person is justified. | Act s.28(2)–(3) | The only indirect collection is from published university accommodation notices, which are public records under s.28(2)(a). The importer keeps the source file and line for every value it stores. | `src/server/extraction.ts; data/public-source` | met |
| 20 | No secret is committed to the repository. | Act s.41 | The environment file is ignored, an example file lists the variables without values, and the secret scan runs as part of the checks. | `.gitignore; .env.example; scripts/secrets-scan.mjs` | met |

---

*Generated from `src/shared/prePublicationChecklist.ts` via `checklistToMarkdown()`. Do not edit this file directly — edit the TypeScript source and regenerate.*